﻿namespace WebApplication5.Models
{
    public class ApplicationModel
    {
        public string Name { get; set; } = string.Empty; 
        public string Executable { get; set; } = string.Empty; 
        public string Parameters { get; set; } = string.Empty; 
        public string Icon { get; set; } = string.Empty; 
    }


}
