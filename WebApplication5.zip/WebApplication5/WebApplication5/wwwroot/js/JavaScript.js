﻿let loadingWindow; // To store reference to the loading window

function launchApp(executable, parameters) {
    console.log("launchApp function called with executable: " + executable + " and parameters: " + parameters);

    const apiUrl = 'http://localhost:5001/api/app/launch'; // Update if needed

    const payload = {
        AppPath: executable,        // Application executable
        Parameters: parameters || "" // Parameters for the application (e.g., URL)
    };

    // Open the loading screen in a new window
    loadingWindow = window.open("", "_blank", "width=400,height=300");
    loadingWindow.document.write(`
        <html>
            <head>
                <title>Loading...</title>
                <style>
                    body { text-align: center; margin-top: 50px; }
                    .spinner { 
                        border: 16px solid #f3f3f3; 
                        border-radius: 50%; 
                        border-top: 16px solid #3498db; 
                        width: 120px; 
                        height: 120px; 
                        animation: spin 2s linear infinite; 
                        margin: auto; 
                    }
                    @keyframes spin { 
                        0% { transform: rotate(0deg); } 
                        100% { transform: rotate(360deg); } 
                    }
                </style>
            </head>
            <body>
                <div class="spinner"></div>
                <p>Loading application...</p>
                <button onclick="window.location.href='/Home/Index';">Home</button>
            </body>
        </html>
    `);

    // Make the POST request to launch the application
    fetch(apiUrl, {
        method: 'POST',
        body: JSON.stringify(payload),
        headers: { 'Content-Type': 'application/json' }
    })
        .then(response => {
            if (response.ok) {
                // Application launched successfully, keep the loading window open
                console.log('Application launched successfully');
            } else {
                // If failed to launch, keep the loading window open but don't show failure message
                console.log('Failed to launch application');
            }
        })
        .catch(error => {
            console.log('Error: ' + error.message);
            // Keep the loading window open
        });
}
