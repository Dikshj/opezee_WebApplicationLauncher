using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication5.Models;

public class HomeController : Controller
{
    // Static list to store applications across requests
    private static List<ApplicationModel> _applications = new List<ApplicationModel>();

    // Loads the Index page with the list of applications
    public IActionResult Index()
    {
        // Pass the application list to the view
        return View(_applications);
    }

    // Loads the Settings page
    public IActionResult Settings()
    {
        return View();
    }

    // Handles the POST request to add an application
    [HttpPost]
    public IActionResult AddApplication(string appPath, string parameters)
    {
        // Add the application to the static list
        _applications.Add(new ApplicationModel
        {
            Name = System.IO.Path.GetFileNameWithoutExtension(appPath),
            Executable = appPath,
            Parameters = parameters,
            Icon = "/images/app1.png" // Assuming a placeholder icon for now
        });

        // Redirect back to the Index page
        return RedirectToAction("Index");
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
