﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

[ApiController]
[Route("api/[controller]")]
public class ValuesController : ControllerBase
{
    [HttpPost("launch")]
    public IActionResult LaunchApp([FromBody] LaunchRequest request)
    {
        try
        {
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = request.AppPath, // Path to the application to launch
                Arguments = request.Parameters, // Arguments to pass to the application
                UseShellExecute = true // Needed for launching a UI application on some systems
            };
            Process.Start(startInfo);
            return Ok("Application launched successfully");
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Error launching application: {ex.Message}");
        }
    }

    [HttpPost("quit")]
    public IActionResult QuitApp()
    {
        try
        {
            // Implement logic to quit the application
            // Example: find the process by name and close it
            var processName = "WebApplication5"; // You can update this to the actual name of the process you want to quit
            var processes = Process.GetProcessesByName(processName);
            foreach (var process in processes)
            {
                process.Kill();
            }

            return Ok("Application quit successfully");
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Error quitting application: {ex.Message}");
        }
    }
}

// Class for receiving request payload
public class LaunchRequest
{
    public string AppPath { get; set; } // The path to the application
    public string Parameters { get; set; } // Optional parameters for the application
}
